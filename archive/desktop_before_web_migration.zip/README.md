# Assignment Statement DFA Validator

A local Windows desktop application for **Design and Implementation of an
Assignment Statement Validator Using Deterministic Finite Automata (DFA)**.
Python, CustomTkinter, and Tkinter Canvas; no server, account, or online runtime.

## Install and run on Windows

Install Python **3.10 or newer** with Tcl/Tk support (included in the standard
Windows Python installer). In PowerShell, open this project directory and run:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\run_windows.bat
```

Alternatively launch with `.\.venv\Scripts\python.exe main.py`.
No environment activation is needed. If `py` is unavailable, substitute the full
path to a working Python executable. A Microsoft Store alias named `python` can
fail even when another Python installation works.

This workspace's Python installation was missing its Tcl/Tk 9.0 script libraries.
Matching scripts were staged under the ignored `artifacts/runtime/` directory for
live verification. The launcher detects and uses that local fallback when needed,
without modifying the system. Preserve this folder on this machine. For a fresh
installation elsewhere, install Python with Tcl/Tk support normally.

Dependency installation needs internet access once. Subsequent launches run
offline. For an offline computer, download dependencies on an internet-connected
machine using `python -m pip download -r requirements.txt -d wheels`, copy this
project and the wheels folder, and install with
`.\.venv\Scripts\python.exe -m pip install --no-index --find-links wheels -r requirements.txt`.

## Use

- **Dashboard:** project overview, quick examples, manual accept/reject counts,
  and number passed in the latest laboratory run.
- **Assignment Validator:** enter a statement, then click **Validate Statement**
  or press **Ctrl+Enter**. Rejections include an explanation, character position,
  token index, and error highlighting when a character exists at that location.
  End-of-input errors have a location immediately after the final character.
- **DFA Diagram:** inspect the machine before validation or see the actual last
  path. Double circles identify Q9; blue identifies the current state; teal
  identifies the visited prefix; red identifies rejection. Reset clears playback,
  Show Full Path restores it, and Fit Diagram fits while preserving readable text.
  Actual Size and scrollbars/pan support smaller windows. Rejection edges are
  collapsed by default for clarity; the executed rejection is always shown.
  Enable **Show rejection edges** to expand all grouped rejecting transitions.
- **Transition Trace:** view the complete execution table, scroll horizontally to
  read explanations, and use Previous/Next/Reset or select a row to replay its
  prefix. Playback and diagram state stay synchronized. Whitespace and EOF count
  as tokens. A lower panel repeats the selected transition and explanation.
- **Test Laboratory:** run 48 cases, inspect expected/actual/PASS/FAIL, filter by
  expected validity or outcome, and double-click a row to load it into the editor.
  A PASS means the result agrees with the expectation, including expected rejection.
- **Grammar and Help:** full grammar, limitations, states, and runtime transition
  table. The help areas and wide table scroll independently.

Editing/loading input does not change the latest executed diagram or trace until
validation. Each view labels the last input. Lab runs do not overwrite manual
validation history. Session counters reset when the application closes.

## Supported syntax

```text
int identifier = integer operator integer { operator integer } ;
```

At least one space/tab follows the exact lowercase `int` keyword. Other spaces
and tabs are optional, including leading/trailing ones. Identifiers start with an
ASCII letter or underscore; subsequent characters may also be ASCII digits.
The grammar permits `int` as an identifier spelling; this is a teaching language,
not a full C validator. Operands are unsigned ASCII digit strings, including
leading zeros. Operators are `+ - * /`; at least one is mandatory.

```c
int a = 8 + 8;
int sum = 1+2+3-8*2/8;
int x_1 = 8/05;
```

Rejected examples: `int a=8;`, `inta=5+5;`, `int 1a=5+5;`, `int a=5++5;`,
`int a=x+1;`, `int a=8/00;`, and `int a=8+8;;`.

The DFA accepts the syntax of `int a=8/00;`; a separate semantic check rejects the
all-zero literal divisor. Its trace correctly ends at **Q9**, with the semantic
failure explained separately. No expression evaluation or Python `eval()` is used.

No variables on the right, unary signs, parentheses, decimals, comments, newlines,
multiple assignments, other declaration types, or Unicode identifiers/digits.
This application does not calculate arithmetic values, enforce overflow bounds,
or implement the full semantics of a programming language.

See [grammar specification](docs/grammar.md) and
[complete transition table](docs/transition_table.md).

## Architecture

```text
main.py                       Desktop entry point
app/main_window.py            Six pages and session state
app/navigation.py             Persistent sidebar
app/theme.py                  Shared visual palette
core/tokenizer.py             Lossless tokens, classes, and character spans
core/dfa_engine.py            States, total δ function, trace, grouped edges
core/validator.py             Syntax/semantic orchestration and diagnostics
core/semantic_checker.py      Literal division-by-zero check
visualization/dfa_canvas.py   Diagram generated from runtime transitions
data/test_cases.json          Shared laboratory expectations
tests/                        Headless unittest suite
tools/gui_smoke.py            Optional live-window integration check
tools/export_transition_table.py  Documentation generator
docs/                         Grammar and generated DFA table
```

The tokenizer retains spaces and tabs to enforce the keyword separator. A total
transition dictionary maps every `(state, token category)` pair to one state.
Undefined grammar moves explicitly enter DEAD, whose moves are absorbing.
Execution stops at the first rejection, retaining that transition, or reaches
Q9 only after consuming EOF. Syntactic rejection takes priority over semantics.
The validator, trace, diagram, help table, exported table, and laboratory all
use these same core definitions. The UI imports no separate validation rules.
Integer strings are checked without converting to Python integers, avoiding
digit-limit failures and supporting long leading-zero operands.

## Verify

The core suite needs only Python's standard library:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -v
.\.venv\Scripts\python.exe -m compileall -q app core visualization tests tools main.py
.\.venv\Scripts\python.exe tools/export_transition_table.py
```

Tests cover identifier classes, invalid characters, spans, whitespace, all supplied
examples, a total/closed DFA, exact paths and accepting/dead states, EOF, diagram
edge agreement, semantic separation, long integers, useful diagnostics, and 200
generated valid statements with three invalid mutations each. Each laboratory
expectation is also exercised as a unittest subtest.

For live-window checks with dependencies installed and a Windows desktop:

```powershell
.\.venv\Scripts\python.exe tools/gui_smoke.py
```

This opens the actual application briefly and checks navigation, laboratory
filters, valid/syntax-invalid/semantic-invalid results, trace replay, diagram
controls, and resizing. It exits nonzero if an assertion or Tk callback fails.

See [verification results and environment notes](docs/verification.md).
