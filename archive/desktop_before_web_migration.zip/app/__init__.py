"""Desktop presentation layer."""
