"""Six-page desktop application, backed by one validation service."""
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk
import customtkinter as ctk

from app import theme as T
from app.navigation import PAGES, Sidebar
from core.dfa_engine import ALPHABET, STATES, STATE_DESCRIPTIONS, TRANSITIONS
from core.tokenizer import Category
from core.validator import validate
from visualization.dfa_canvas import DFACanvas

ROOT = Path(__file__).resolve().parent.parent


def load_test_cases():
    with (ROOT / "data" / "test_cases.json").open(encoding="utf-8") as stream:
        return json.load(stream)


class Application(ctk.CTk):
    def __init__(self):
        ctk.set_appearance_mode("dark")
        super().__init__()
        self.title("DFA Studio | Assignment Statement Validator")
        self.geometry("1360x900")
        self.minsize(1100, 760)
        self.configure(fg_color=T.BG)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.latest_result = None
        self.trace_position = 0
        self.accepted_count = 0
        self.rejected_count = 0
        self.lab_results = {}
        self.test_cases = load_test_cases()
        self.sidebar = Sidebar(self, self.show_page)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.content = ctk.CTkFrame(self, fg_color=T.BG, corner_radius=0)
        self.content.grid(row=0, column=1, sticky="nsew", padx=24, pady=20)
        self.content.rowconfigure(0, weight=1)
        self.content.columnconfigure(0, weight=1)
        self.pages = {}
        self._configure_tables()
        self._build_dashboard()
        self._build_validator()
        self._build_diagram()
        self._build_trace()
        self._build_laboratory()
        self._build_help()
        self.show_page(PAGES[0])
        self.bind("<Control-Return>", lambda _event: self.run_validation())

    def _configure_tables(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Treeview", background=T.CARD, fieldbackground=T.CARD, foreground=T.TEXT,
                        borderwidth=0, rowheight=34, font=(T.FONT, 11))
        style.configure("Treeview.Heading", background=T.CARD_ALT, foreground=T.TEXT,
                        font=(T.FONT, 11, "bold"), padding=9, relief="flat")
        style.map("Treeview", background=[("selected", "#265175")], foreground=[("selected", "white")])

    def _page(self, name, subtitle, scroll=False):
        frame = ctk.CTkFrame(self.content, fg_color=T.BG, corner_radius=0)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(2, weight=1)
        ctk.CTkLabel(frame, text=name, font=(T.FONT, 29, "bold"), text_color=T.TEXT).grid(row=0, column=0, sticky="w", pady=(5, 4))
        ctk.CTkLabel(frame, text=subtitle, font=(T.FONT, 13), text_color=T.MUTED, anchor="w").grid(row=1, column=0, sticky="ew", pady=(0, 20))
        body = ctk.CTkScrollableFrame(frame, fg_color=T.BG) if scroll else ctk.CTkFrame(frame, fg_color=T.BG)
        body.grid(row=2, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        self.pages[name] = frame
        return body

    def _label(self, master, text, *, size=14, color=T.TEXT, bold=False, **kwargs):
        return ctk.CTkLabel(master, text=text, font=(T.FONT, size, "bold" if bold else "normal"),
                            text_color=color, justify="left", anchor="w", **kwargs)

    def _button(self, master, text, command, primary=False, **kwargs):
        return ctk.CTkButton(master, text=text, command=command, height=38, corner_radius=8,
                            font=(T.FONT, 12, "bold"), fg_color=T.ACCENT if primary else T.CARD_ALT,
                            text_color=T.BG if primary else T.TEXT,
                            hover_color="#78E1D4" if primary else "#304664", **kwargs)

    def _card(self, parent):
        card = ctk.CTkFrame(parent, fg_color=T.CARD, corner_radius=14)
        card.columnconfigure(0, weight=1)
        return card

    def _table(self, parent, columns, widths):
        container = ctk.CTkFrame(parent, fg_color=T.CARD)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)
        table = ttk.Treeview(container, columns=columns, show="headings", selectmode="browse")
        for column, width in zip(columns, widths):
            table.heading(column, text=column)
            table.column(column, width=width, minwidth=width, stretch=column == columns[-1])
        table.grid(row=0, column=0, sticky="nsew")
        yscroll = ttk.Scrollbar(container, orient="vertical", command=table.yview)
        xscroll = ttk.Scrollbar(container, orient="horizontal", command=table.xview)
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        table.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        table.tag_configure("pass", foreground=T.GREEN)
        table.tag_configure("fail", foreground=T.RED)
        return container, table

    def show_page(self, name):
        self.pages[name].tkraise()
        self.sidebar.select(name)
        if name == "DFA Diagram":
            self.diagram.after_idle(self.diagram.draw)

    def _build_dashboard(self):
        body = self._page("Dashboard", "Design and Implementation of an Assignment Statement Validator Using DFA", scroll=True)
        hero = self._card(body)
        hero.grid(row=0, column=0, sticky="ew", pady=(0, 20))
        self._label(hero, "Follow every transition.", size=28, bold=True).grid(row=0, column=0, padx=26, pady=(24, 12), sticky="w")
        self._label(hero, "Explore how a deterministic finite automaton recognizes a restricted integer assignment grammar.",
                    wraplength=700, color=T.MUTED).grid(row=1, column=0, padx=26, sticky="w")
        self._label(hero, "int sum = 1 + 2 + 3 - 8 * 2 / 8;", size=22, color=T.ACCENT).grid(row=2, column=0, padx=26, pady=22, sticky="w")
        self._button(hero, "Open Assignment Validator  →", lambda: self.show_page("Assignment Validator"), True, width=260).grid(row=3, column=0, padx=26, pady=(0, 25), sticky="w")
        stats = ctk.CTkFrame(body, fg_color="transparent")
        stats.grid(row=1, column=0, sticky="ew", pady=(0, 22))
        self.stat_labels = []
        for index, (caption, color) in enumerate((("ACCEPTED", T.GREEN), ("REJECTED", T.RED), ("LAB TESTS PASSED", T.BLUE))):
            stats.columnconfigure(index, weight=1)
            card = self._card(stats)
            card.grid(row=0, column=index, padx=(0, 10), sticky="ew")
            value = self._label(card, "0", size=30, color=color, bold=True)
            value.grid(row=0, column=0, padx=20, pady=(15, 0), sticky="w")
            self._label(card, caption, size=11, color=T.MUTED).grid(row=1, column=0, padx=20, pady=(0, 15), sticky="w")
            self.stat_labels.append(value)
        self._label(body, "Your first validation", size=19, bold=True).grid(row=2, column=0, sticky="w", pady=(0, 12))
        self._label(body, "1. Enter an int assignment with at least one arithmetic operator.\n2. Validate, then review the result and error location.\n3. Inspect the live DFA path and replay its transition trace.",
                    color=T.MUTED).grid(row=3, column=0, sticky="w", pady=(0, 22))
        self._label(body, "Quick-start examples", size=19, bold=True).grid(row=4, column=0, sticky="w", pady=(0, 10))
        for row, source in enumerate(("int a = 8 + 8;", "int sum = 1+2+3-8*2/8;", "int a = 8/00;"), 5):
            self._button(body, source + "    →", lambda value=source: self.load_source(value), anchor="w").grid(row=row, column=0, sticky="ew", pady=4)
        self._label(body, "Counters track manual validations and the latest laboratory run in this session.", size=11, color=T.MUTED).grid(row=8, column=0, pady=18, sticky="w")

    def _build_validator(self):
        body = self._page("Assignment Validator", "Enter one statement. Ctrl + Enter validates from any page.", scroll=True)
        card = self._card(body)
        card.grid(row=0, column=0, sticky="ew")
        self._label(card, "ASSIGNMENT INPUT", size=12, color=T.MUTED, bold=True).grid(row=0, column=0, padx=20, pady=(18, 10), sticky="w")
        self.input = ctk.CTkTextbox(card, height=135, font=(T.MONO, 21), fg_color=T.BG, text_color=T.TEXT, wrap="word")
        self.input.grid(row=1, column=0, padx=20, sticky="ew")
        self.input.insert("1.0", "int a = 8 + 8;")
        self.input._textbox.tag_configure("error", background="#6C3043", foreground="white")
        controls = ctk.CTkFrame(card, fg_color="transparent")
        controls.grid(row=2, column=0, sticky="w", padx=20, pady=18)
        self._button(controls, "Validate Statement", self.run_validation, True, width=175).grid(row=0, column=0, padx=(0, 8))
        self._button(controls, "Clear Input", self.clear_input, width=115).grid(row=0, column=1, padx=4)
        self._button(controls, "Load Valid Example", lambda: self.load_source("int sum = 1+2+3-8*2/8;"), width=155).grid(row=0, column=2, padx=4)
        self._button(controls, "Load Invalid Example", lambda: self.load_source("int a = 5++5;"), width=165).grid(row=0, column=3, padx=4)
        self.result_card = self._card(body)
        self.result_card.grid(row=1, column=0, sticky="ew", pady=20)
        self.result_title = self._label(self.result_card, "READY TO VALIDATE", size=23, color=T.BLUE, bold=True)
        self.result_title.grid(row=0, column=0, padx=22, pady=(20, 10), sticky="w")
        self.result_message = self._label(self.result_card, "Enter a statement above and select Validate Statement.", wraplength=700)
        self.result_message.grid(row=1, column=0, padx=22, sticky="w")
        self.result_location = self._label(self.result_card, "", color=T.MUTED, wraplength=700)
        self.result_location.grid(row=2, column=0, padx=22, pady=(10, 20), sticky="w")
        links = ctk.CTkFrame(body, fg_color="transparent")
        links.grid(row=2, column=0, sticky="w")
        self._button(links, "View DFA Diagram  →", lambda: self.show_page("DFA Diagram"), width=180).grid(row=0, column=0, padx=(0, 10))
        self._button(links, "View Transition Trace  →", lambda: self.show_page("Transition Trace"), width=190).grid(row=0, column=1)
        self._label(body, "Unsigned integers only • At least one operation • One semicolon\nSpaces and tabs are supported; line breaks are outside this grammar.",
                    color=T.MUTED, size=12).grid(row=3, column=0, sticky="w", pady=24)
        self.input.bind("<KeyRelease>", self._input_changed)

    def _input_changed(self, _event=None):
        self.input._textbox.tag_remove("error", "1.0", "end")
        if self.latest_result and self.input.get("1.0", "end-1c") != self.latest_result.source:
            self.result_title.configure(text="INPUT CHANGED — VALIDATE AGAIN", text_color=T.BLUE)
            self.result_message.configure(text="The diagram and trace still show the last validated statement.")
            self.result_location.configure(text="")

    def load_source(self, source):
        self.input.delete("1.0", "end")
        self.input.insert("1.0", source)
        self.show_page("Assignment Validator")
        self.result_title.configure(text="READY TO VALIDATE", text_color=T.BLUE)
        self.result_message.configure(text="Example loaded. Select Validate Statement to inspect its execution.")
        self.result_location.configure(text="")
        self.input.focus_set()

    def clear_input(self):
        self.load_source("")
        self.result_message.configure(text="Enter a new assignment statement.")

    def run_validation(self):
        result = validate(self.input.get("1.0", "end-1c"))
        self.latest_result = result
        self.accepted_count += int(result.accepted)
        self.rejected_count += int(not result.accepted)
        self.result_title.configure(text="ACCEPTED" if result.accepted else "REJECTED", text_color=T.GREEN if result.accepted else T.RED)
        self.result_message.configure(text=result.message)
        syntax = f"Syntax DFA: {'accepted' if result.syntax_accepted else 'rejected'} at {result.dfa.final_state}."
        if result.error_start is not None:
            location = f"Character {result.error_start+1} • Token {result.error_token_index} (including whitespace)."
            self.result_location.configure(text=f"{location}\n{syntax}" + (" Semantic check: rejected." if result.syntax_accepted else ""))
        else:
            self.result_location.configure(text=syntax + " Semantic check: passed.")
        self.input._textbox.tag_remove("error", "1.0", "end")
        if result.error_start is not None:
            start = f"1.0+{result.error_start}c"
            end = f"1.0+{max(result.error_end, result.error_start+1)}c"
            self.input._textbox.tag_add("error", start, end)
            self.input.see(start)
        self.trace_position = len(result.dfa.trace)
        self.diagram.set_execution(result.dfa.trace)
        self.diagram_caption.configure(text=self._execution_caption())
        self._populate_trace()
        self._update_stats()
        self.show_page("Assignment Validator")

    def _execution_caption(self):
        if not self.latest_result:
            return "No execution yet. Inspect the DFA or validate a statement to highlight its path."
        source = self.latest_result.source.replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r")
        summary = f"Last input: {source[:100]}{'…' if len(source) > 100 else ''}"
        if self.latest_result.syntax_accepted and not self.latest_result.accepted:
            summary += "  |  Syntax accepted; semantic rejection: division by zero."
        return summary

    def _build_diagram(self):
        body = self._page("DFA Diagram", "The live transition function, including explicit whitespace and end-of-input handling.")
        body.rowconfigure(2, weight=1)
        controls = ctk.CTkFrame(body, fg_color="transparent")
        controls.grid(row=0, column=0, sticky="w", pady=(0, 10))
        self._button(controls, "Reset Diagram", self.reset_diagram, width=130).grid(row=0, column=0, padx=(0, 8))
        self._button(controls, "Fit Diagram", lambda: self.diagram.fit(), width=115).grid(row=0, column=1, padx=4)
        self._button(controls, "Actual Size", lambda: self.diagram.actual_size(), width=110).grid(row=0, column=2, padx=4)
        self._button(controls, "Show Full Path", self.show_full_path, width=130).grid(row=0, column=3, padx=4)
        self.reject_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(controls, text="Show rejection edges", variable=self.reject_var, command=self.toggle_rejection_edges,
                        font=(T.FONT, 12), checkbox_width=20, checkbox_height=20).grid(row=0, column=4, padx=12)
        self.diagram_caption = self._label(body, self._execution_caption(), color=T.MUTED, size=12, wraplength=850)
        self.diagram_caption.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self.diagram = DFACanvas(body)
        self.diagram.grid(row=2, column=0, sticky="nsew")

    def toggle_rejection_edges(self):
        self.diagram.show_rejections = self.reject_var.get()
        self.diagram.draw()

    def reset_diagram(self):
        self.trace_position = 0
        self.diagram.reset()
        self._sync_trace_selection()

    def show_full_path(self):
        if self.latest_result:
            self.trace_position = len(self.latest_result.dfa.trace)
            self.diagram.set_execution(self.latest_result.dfa.trace)
            self._sync_trace_selection()

    def _build_trace(self):
        body = self._page("Transition Trace", "Every row comes directly from the DFA execution. Select a row to replay that prefix.")
        body.rowconfigure(2, weight=1)
        controls = ctk.CTkFrame(body, fg_color="transparent")
        controls.grid(row=0, column=0, sticky="w", pady=(0, 12))
        self.previous_button = self._button(controls, "← Previous Step", lambda: self.move_trace(-1), width=145)
        self.previous_button.grid(row=0, column=0, padx=(0, 8))
        self.next_button = self._button(controls, "Next Step →", lambda: self.move_trace(1), width=125)
        self.next_button.grid(row=0, column=1, padx=4)
        self._button(controls, "Reset Trace", self.reset_diagram, width=115).grid(row=0, column=2, padx=4)
        self._button(controls, "View Diagram", lambda: self.show_page("DFA Diagram"), width=130).grid(row=0, column=3, padx=4)
        self.trace_status = self._label(body, "No validation yet.", color=T.MUTED, wraplength=850)
        self.trace_status.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        container, self.trace_table = self._table(body,
            ("Step", "Input token", "Token category", "Previous state", "Transition", "Next state", "Explanation"),
            (60, 120, 145, 125, 265, 110, 440))
        container.grid(row=2, column=0, sticky="nsew")
        self.trace_table.bind("<<TreeviewSelect>>", self._select_trace)
        self.trace_detail = self._label(body, "Whitespace tokens and <end> are intentionally included.", color=T.MUTED, wraplength=850)
        self.trace_detail.grid(row=3, column=0, sticky="ew", pady=15)
        self._sync_trace_selection()

    def _populate_trace(self):
        self.trace_table.delete(*self.trace_table.get_children())
        for step in self.latest_result.dfa.trace:
            self.trace_table.insert("", "end", iid=str(step.number), values=(step.number, step.token.display,
                step.token.category.value, step.previous, step.transition_label, step.following, step.explanation),
                tags=("fail",) if step.following == "DEAD" else ())
        self._sync_trace_selection()

    def move_trace(self, amount):
        if self.latest_result:
            self.trace_position = max(0, min(len(self.latest_result.dfa.trace), self.trace_position+amount))
            self.diagram.set_execution(self.latest_result.dfa.trace, self.trace_position)
            self._sync_trace_selection()

    def _select_trace(self, _event=None):
        selected = self.trace_table.selection()
        if selected and self.latest_result:
            position = int(selected[0])
            if position != self.trace_position:
                self.trace_position = position
                self.diagram.set_execution(self.latest_result.dfa.trace, position)
                self._sync_trace_selection()

    def _sync_trace_selection(self):
        total = len(self.latest_result.dfa.trace) if self.latest_result else 0
        self.previous_button.configure(state="normal" if self.trace_position > 0 else "disabled")
        self.next_button.configure(state="normal" if self.trace_position < total else "disabled")
        if not self.latest_result:
            return
        self.trace_status.configure(text=f"Step {self.trace_position} of {total}   |   " + self._execution_caption())
        if self.trace_position:
            row = str(self.trace_position)
            self.trace_table.selection_set(row)
            self.trace_table.see(row)
            step = self.latest_result.dfa.trace[self.trace_position-1]
            self.trace_detail.configure(text=f"{step.transition_label}\n{step.explanation}")
        else:
            self.trace_table.selection_remove(*self.trace_table.selection())
            self.trace_detail.configure(text="Initial state Q0. No input token has been consumed.")

    def _build_laboratory(self):
        body = self._page("Test Laboratory", "Run the predefined cases against the same validation service used by the editor.")
        body.rowconfigure(2, weight=1)
        controls = ctk.CTkFrame(body, fg_color="transparent")
        controls.grid(row=0, column=0, sticky="w", pady=(0, 15))
        self._button(controls, "Run All Tests", self.run_lab, True, width=135).grid(row=0, column=0, padx=(0, 12))
        self.lab_filter = ctk.CTkOptionMenu(controls, values=["All", "Valid", "Invalid", "Passed", "Failed"],
                                           command=lambda _value: self.populate_lab(), fg_color=T.CARD_ALT,
                                           button_color="#304664", width=140)
        self.lab_filter.grid(row=0, column=1, padx=6)
        self._button(controls, "Load Selected into Validator", self.load_selected_case, width=220).grid(row=0, column=2, padx=8)
        self.lab_status = self._label(body, f"Total: {len(self.test_cases)}   |   Passed: 0   |   Failed: 0   |   Not run: {len(self.test_cases)}", color=T.MUTED)
        self.lab_status.grid(row=1, column=0, sticky="w", pady=(0, 14))
        container, self.lab_table = self._table(body, ("ID", "Statement", "Expected", "Actual", "Status", "Purpose"), (50, 300, 95, 95, 85, 280))
        container.grid(row=2, column=0, sticky="nsew")
        self.lab_table.bind("<Double-1>", lambda _event: self.load_selected_case())
        self.lab_detail = self._label(body, "Select a case and load it into the validator, or double-click its row.", color=T.MUTED, wraplength=850)
        self.lab_detail.grid(row=3, column=0, pady=14, sticky="ew")
        self.lab_table.bind("<<TreeviewSelect>>", self._lab_selection)
        self.populate_lab()

    def run_lab(self):
        self.lab_results = {index: validate(case["source"]) for index, case in enumerate(self.test_cases)}
        passed = sum(self.lab_results[index].accepted == case["expected"] for index, case in enumerate(self.test_cases))
        self.lab_status.configure(text=f"Total: {len(self.test_cases)}   |   Passed: {passed}   |   Failed: {len(self.test_cases)-passed}   |   Not run: 0")
        self.populate_lab()
        self._update_stats()

    def populate_lab(self):
        self.lab_table.delete(*self.lab_table.get_children())
        chosen = self.lab_filter.get()
        for index, case in enumerate(self.test_cases):
            result = self.lab_results.get(index)
            passed = result.accepted == case["expected"] if result else None
            if chosen == "Valid" and not case["expected"] or chosen == "Invalid" and case["expected"]:
                continue
            if chosen == "Passed" and passed is not True or chosen == "Failed" and passed is not False:
                continue
            status = "NOT RUN" if passed is None else "PASS" if passed else "FAIL"
            self.lab_table.insert("", "end", iid=str(index), values=(index+1,
                case["source"].replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r"),
                "ACCEPT" if case["expected"] else "REJECT", "—" if not result else "ACCEPT" if result.accepted else "REJECT",
                status, case["purpose"]), tags=() if passed is None else ("pass" if passed else "fail",))

    def _lab_selection(self, _event=None):
        selection = self.lab_table.selection()
        if selection:
            index = int(selection[0])
            result = self.lab_results.get(index)
            self.lab_detail.configure(text=result.message if result else self.test_cases[index]["purpose"])

    def load_selected_case(self):
        selected = self.lab_table.selection()
        if selected:
            self.load_source(self.test_cases[int(selected[0])]["source"])
        else:
            self.lab_detail.configure(text="Select a test case row first.")

    def _update_stats(self):
        passed = sum(result.accepted == self.test_cases[index]["expected"] for index, result in self.lab_results.items())
        for label, value in zip(self.stat_labels, (self.accepted_count, self.rejected_count, passed)):
            label.configure(text=str(value))

    def _build_help(self):
        body = self._page("Grammar and Help", "A precise specification of the language, state machine, and its limits.", scroll=True)
        grammar = (ROOT / "docs" / "grammar.md").read_text(encoding="utf-8")
        self._label(body, "Supported grammar", size=20, bold=True).grid(row=0, column=0, sticky="w", pady=(0, 10))
        box = ctk.CTkTextbox(body, height=405, font=(T.MONO, 13), fg_color=T.CARD, wrap="word")
        box.grid(row=1, column=0, sticky="ew", pady=(0, 18))
        box.insert("1.0", grammar)
        box.configure(state="disabled")
        self._label(body, "States and acceptance", size=20, bold=True).grid(row=2, column=0, sticky="w", pady=(0, 10))
        state_text = "\n".join(f"{state:5}  {description}" for state, description in STATE_DESCRIPTIONS.items())
        states = ctk.CTkTextbox(body, height=310, font=(T.MONO, 13), fg_color=T.CARD, wrap="word")
        states.grid(row=3, column=0, sticky="ew", pady=(0, 18))
        states.insert("1.0", state_text + "\n\nQ9 is the sole accepting state. DEAD rejects all continuations.\nWhitespace tokens are maximal runs of spaces or tabs; EOF is explicit.")
        states.configure(state="disabled")
        self._label(body, "Complete transition table", size=20, bold=True).grid(row=4, column=0, sticky="w", pady=(0, 10))
        container, table = self._table(body, ("State",) + tuple(category.value for category in ALPHABET), (70,) + (145,)*len(ALPHABET))
        container.configure(height=425)
        container.grid_propagate(False)
        container.grid(row=5, column=0, sticky="ew", pady=(0, 20))
        for state in STATES:
            table.insert("", "end", values=(state,) + tuple(TRANSITIONS[state, category] for category in ALPHABET))


def main():
    Application().mainloop()
