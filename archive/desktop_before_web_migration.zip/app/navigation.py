"""Persistent sidebar with visible active-page styling."""
import customtkinter as ctk
from app import theme as T

PAGES = ("Dashboard", "Assignment Validator", "DFA Diagram", "Transition Trace", "Test Laboratory", "Grammar and Help")
SYMBOLS = ("◈", "›_", "◎", "≡", "✓", "?")


class Sidebar(ctk.CTkFrame):
    def __init__(self, master, on_select):
        super().__init__(master, width=235, fg_color=T.SIDEBAR, corner_radius=0)
        self.grid_propagate(False)
        self.grid_rowconfigure(8, weight=1)
        ctk.CTkLabel(self, text="DFA / STUDIO", font=(T.FONT, 23, "bold"), text_color=T.ACCENT).grid(row=0, column=0, padx=22, pady=(30, 3), sticky="w")
        ctk.CTkLabel(self, text="ASSIGNMENT VALIDATOR", font=(T.FONT, 10, "bold"), text_color=T.MUTED).grid(row=1, column=0, padx=23, pady=(0, 30), sticky="w")
        self.buttons = {}
        for row, (name, symbol) in enumerate(zip(PAGES, SYMBOLS), 2):
            button = ctk.CTkButton(self, text=f"{symbol}   {name}", anchor="w", width=205, height=44,
                                  font=(T.FONT, 13), fg_color="transparent", hover_color=T.CARD_ALT,
                                  text_color=T.MUTED, command=lambda page=name: on_select(page))
            button.grid(row=row, column=0, padx=14, pady=5)
            self.buttons[name] = button
        ctk.CTkLabel(self, text="AUTOMATA THEORY\nLocal • deterministic • explainable", justify="left",
                     font=(T.FONT, 11), text_color=T.MUTED).grid(row=9, column=0, padx=23, pady=25, sticky="w")

    def select(self, page):
        for name, button in self.buttons.items():
            button.configure(fg_color=T.CARD_ALT if name == page else "transparent",
                             text_color=T.ACCENT if name == page else T.MUTED)
