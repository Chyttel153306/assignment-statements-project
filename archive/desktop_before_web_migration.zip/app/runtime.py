"""Optional workspace-only fallback for an incomplete host Python installation."""
import os
from pathlib import Path
import sys


def configure_local_tk():
    """Use locally staged Tcl/Tk 9.0 scripts only when standard scripts are absent.

    Normal Windows Python installations never need this. No files are downloaded
    or system settings changed; these environment variables affect this process.
    """
    import _tkinter
    if _tkinter.TCL_VERSION != "9.0":
        return
    base = Path(sys.base_prefix)
    standard = (base / "tcl" / "tcl9.0" / "init.tcl", base / "lib" / "tcl9.0" / "init.tcl")
    if any(path.exists() for path in standard):
        return
    runtime = Path(__file__).resolve().parent.parent / "artifacts" / "runtime"
    tcl = runtime / "tcl-core-9-0-4" / "library"
    tk = runtime / "tk-core-9-0-4" / "library"
    if (tcl / "init.tcl").exists() and (tk / "tk.tcl").exists():
        os.environ.setdefault("TCL_LIBRARY", str(tcl))
        os.environ.setdefault("TK_LIBRARY", str(tk))
