# Verification record

Verified on Windows on 22 October 2026 with Python 3.14.7 and CustomTkinter 5.2.2.

- `python -m unittest discover -v`: **25 tests passed**. Includes all 48
  laboratory expectations and 200 generated valid assignments, each checked with
  three rejected mutations (missing semicolon, extra semicolon, and `==`).
- `python tools/gui_smoke.py`: **passed** against a real Tk window. Exercised
  all six pages, 48 laboratory results, all filters, loading test cases, successful
  validation, syntax errors, semantic zero-division errors, empty input, EOF error
  positions, actual trace rows, step replay, row selection, diagram reset/fit/full
  path/rejection edges/actual size, clear input, and three window sizes. Checked
  button bounds at the minimum size and captured Tk callback failures as errors.
- `python -m compileall -q app core visualization tests tools main.py`: **passed**.
- Exported transition table directly from the runtime transition dictionary.
- Launched `main.py` on the interactive desktop; startup log was empty.

The separate Windows screenshot service failed with `FrameArrived timed out:
timed out waiting on channel`, then `window capture timed out: timed out waiting
on channel` on recovery. Screenshot-based visual inspection could not be
completed. Live widget integration and control-bounds checks passed.

The host Python had the Tcl/Tk DLLs but lacked the script libraries. Matching
Tcl/Tk 9.0.4 libraries were staged in the ignored `artifacts/runtime/` folder;
`app/runtime.py` uses them locally only if the normal installation scripts are
missing. Standard Python installations with Tcl/Tk support need no fallback.
