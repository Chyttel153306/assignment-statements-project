"""Windows/local desktop entry point."""
import sys


def main():
    from app.runtime import configure_local_tk
    configure_local_tk()
    try:
        from app.main_window import main as run_app
    except ModuleNotFoundError as error:
        if error.name == "customtkinter":
            print("CustomTkinter is required. Run: python -m pip install -r requirements.txt", file=sys.stderr)
            return 1
        raise
    run_app()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
