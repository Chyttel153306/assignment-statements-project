"""Live integration checks. Requires a display and the GUI dependencies."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.main_window import Application
from app.navigation import PAGES
from app.runtime import configure_local_tk
import customtkinter as ctk


def check_button_bounds(widget):
    """Detect horizontally clipped controls, including at the minimum size."""
    if isinstance(widget, ctk.CTkButton) and widget.winfo_ismapped():
        assert widget.winfo_x() >= 0, widget.cget("text")
        assert widget.winfo_x() + widget.winfo_width() <= widget.master.winfo_width()+2, (
            widget.cget("text"), widget.winfo_x(), widget.winfo_width(), widget.master.winfo_width())
    for child in widget.winfo_children():
        check_button_bounds(child)


def main():
    configure_local_tk()
    app = Application()
    callback_errors = []
    app.report_callback_exception = lambda *error: callback_errors.append(error)
    try:
        app.update()
        for page in PAGES:
            app.show_page(page)
            app.update()
            assert app.pages[page].winfo_ismapped(), page
        app.run_lab()
        assert len(app.lab_results) == 48
        assert all(result.accepted == app.test_cases[index]["expected"] for index, result in app.lab_results.items())
        for chosen, expected_count in (("Valid", 12), ("Invalid", 36), ("Passed", 48), ("Failed", 0), ("All", 48)):
            app.lab_filter.set(chosen)
            app.populate_lab()
            assert len(app.lab_table.get_children()) == expected_count, chosen
        app.lab_table.selection_set("0")
        app.load_selected_case()
        assert app.input.get("1.0", "end-1c") == app.test_cases[0]["source"]
        for source, accepted, syntax in (("int a=1+2;", True, True), ("int a=1++2;", False, False),
                                         ("int a=8/00;", False, True), ("int a=1+2", False, False),
                                         ("", False, False)):
            app.load_source(source)
            app.run_validation()
            app.update()
            result = app.latest_result
            assert result.accepted == accepted
            assert result.syntax_accepted == syntax
            assert app.result_title.cget("text") == ("ACCEPTED" if accepted else "REJECTED")
            assert len(app.trace_table.get_children()) == len(result.dfa.trace)
            for step in result.dfa.trace:
                row = app.trace_table.item(str(step.number), "values")
                assert row[3] == step.previous and row[5] == step.following
            app.reset_diagram()
            app.update()
            assert app.trace_position == 0 and app.diagram.current_step == 0
            for index in range(len(result.dfa.trace)):
                app.move_trace(1)
                app.update()
                assert app.trace_position == index+1
                assert app.diagram.current_step == index+1
            app.move_trace(-1)
            app.update()
            assert app.trace_position == len(result.dfa.trace)-1
            app.show_full_path()
            assert app.diagram.current_step == len(result.dfa.trace)
        app.load_source("int a=1+2/5;")
        app.run_validation()
        app.trace_table.selection_set("5")
        app.update()
        assert app.trace_position == 5
        assert app.diagram.current_step == 5
        app.show_page("DFA Diagram")
        app.reject_var.set(True)
        app.toggle_rejection_edges()
        app.diagram.actual_size()
        app.update()
        assert app.diagram.canvas.find_all()
        app.diagram.fit()
        for geometry in ("1100x760", "1600x1000", "1360x900"):
            app.geometry(geometry)
            for page in PAGES:
                app.show_page(page)
                app.update()
                check_button_bounds(app)
        app.clear_input()
        app.update()
        assert app.input.get("1.0", "end-1c") == ""
        assert not callback_errors, callback_errors
        print("GUI smoke passed: six pages, 48 lab cases, filters, diagnostics, real trace/diagram agreement, replay, controls, and resizing.")
    finally:
        app.destroy()


if __name__ == "__main__":
    main()
