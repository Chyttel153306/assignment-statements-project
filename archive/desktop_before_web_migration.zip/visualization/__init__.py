"""DFA diagram derived directly from core transition definitions."""
