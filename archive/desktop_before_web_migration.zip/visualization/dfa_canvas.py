"""Resizable, scrollable Tk Canvas view of the actual token DFA."""
import math
import tkinter as tk
from tkinter import ttk
from core.dfa_engine import ACCEPTING_STATES, DEAD_STATE, INITIAL_STATE, grouped_transitions
from app import theme as T


class DFACanvas(ttk.Frame):
    WORLD_WIDTH = 1500
    WORLD_HEIGHT = 820

    def __init__(self, master):
        super().__init__(master)
        self.canvas = tk.Canvas(self, background=T.BG, highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        horizontal = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        vertical = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        horizontal.grid(row=1, column=0, sticky="ew")
        vertical.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(xscrollcommand=horizontal.set, yscrollcommand=vertical.set)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.trace = ()
        self.current_step = 0
        self.show_rejections = False
        self.fitted = True
        self.positions = {f"Q{i}": (135 + i * 295, 180) for i in range(5)}
        self.positions.update({f"Q{i}": (135 + (9-i)*295, 460) for i in range(5, 10)})
        self.positions[DEAD_STATE] = (740, 700)
        self.canvas.bind("<Configure>", lambda _event: self.draw())
        self.canvas.bind("<ButtonPress-1>", lambda event: self.canvas.scan_mark(event.x, event.y))
        self.canvas.bind("<B1-Motion>", lambda event: self.canvas.scan_dragto(event.x, event.y, gain=1))

    def set_execution(self, trace, step=None):
        self.trace = trace
        self.current_step = len(trace) if step is None else step
        self.draw()

    def reset(self):
        self.current_step = 0
        self.draw()

    def fit(self):
        self.fitted = True
        self.canvas.xview_moveto(0)
        self.canvas.yview_moveto(0)
        self.draw()

    def actual_size(self):
        self.fitted = False
        self.draw()

    def draw(self):
        c = self.canvas
        c.delete("all")
        width, height = max(c.winfo_width(), 1), max(c.winfo_height(), 1)
        scale = min(width/self.WORLD_WIDTH, height/self.WORLD_HEIGHT) if self.fitted else 1.0
        scale = max(scale, 0.62)  # Preserve text legibility; small windows use scrollbars.
        c.configure(scrollregion=(0, 0, self.WORLD_WIDTH*scale, self.WORLD_HEIGHT*scale))
        font_size = max(10, round(13*scale))
        radius = 32
        path = self.trace[:self.current_step]
        taken = {(step.previous, step.following) for step in path}
        last_edge = (path[-1].previous, path[-1].following) if path else None
        current = path[-1].following if path else INITIAL_STATE
        visited = {INITIAL_STATE} | {step.following for step in path}

        def line(coords, **kwargs):
            return c.create_line(*[value*scale for value in coords], **kwargs)

        def label(x, y, text, color=T.MUTED, size=font_size):
            # Opaque backing keeps crossing lines from obscuring labels.
            item = c.create_text(x*scale, y*scale, text=text, fill=color, font=(T.FONT, size), justify="center")
            box = c.bbox(item)
            if box:
                backing = c.create_rectangle(box[0]-4, box[1]-2, box[2]+4, box[3]+2, fill=T.BG, outline="")
                c.tag_lower(backing, item)

        label(750, 32, "TOKEN DFA  •  δ(state, category) → next state", T.TEXT, max(12, round(17*scale)))
        label(750, 65, "Teal: visited   /   Blue: current   /   Red: rejection   /   Dashed: all unlisted categories")
        groups = grouped_transitions()
        # Rejection edges are compact by default; the executed rejection is always shown.
        edges = sorted(groups, key=lambda edge: edge in taken)
        for previous, following in edges:
            reject = following == DEAD_STATE
            active = (previous, following) in taken
            if reject and previous != DEAD_STATE and not (self.show_rejections or active):
                continue
            x1, y1 = self.positions[previous]
            x2, y2 = self.positions[following]
            color = T.RED if reject and active else T.BLUE if (previous, following) == last_edge else T.ACCENT if active else "#526681"
            options = dict(fill=color, width=3 if active else 1.4, arrow=tk.LAST, arrowshape=(10, 12, 4))
            if reject:
                options["dash"] = (4, 4)
            names = [category.value for category in groups[previous, following]]
            text = "other" if reject and previous != DEAD_STATE else "all" if previous == DEAD_STATE else " / ".join(names)
            if previous == following:
                # Loops above their state (dead loop to the right).
                line((x1-20, y1-24, x1-68, y1-104, x1+68, y1-104, x1+20, y1-24), smooth=True, **options)
                label(x1, y1-86, text, color)
            elif reject:
                dx, dy = x2-x1, y2-y1
                distance = math.hypot(dx, dy)
                sx, sy = x1+radius*dx/distance, y1+radius*dy/distance
                ex, ey = x2-radius*dx/distance, y2-radius*dy/distance
                line((sx, sy, ex, ey), **options)
                label(sx*0.25+ex*0.75, sy*0.25+ey*0.75, text, color)
            elif {previous, following} == {"Q6", "Q7"}:
                bend = -62 if previous == "Q6" else 62
                dx = 1 if x2 > x1 else -1
                line((x1+dx*radius, y1, (x1+x2)/2, y1+bend, x2-dx*radius, y2), smooth=True, **options)
                label((x1+x2)/2, y1+bend*0.65, text, color)
            else:
                dx, dy = x2-x1, y2-y1
                distance = math.hypot(dx, dy)
                line((x1+radius*dx/distance, y1+radius*dy/distance,
                      x2-radius*dx/distance, y2-radius*dy/distance), **options)
                label((x1+x2)/2 + (68 if dx == 0 else 0), (y1+y2)/2 - (20 if dy == 0 else 0), text, color)

        line((45, 180, 99, 180), fill=T.ACCENT, width=2, arrow=tk.LAST)
        for state, (x, y) in self.positions.items():
            fill = "#482839" if state == DEAD_STATE else "#244C79" if state == current else "#174B4A" if state in visited else T.CARD
            outline = T.RED if state == DEAD_STATE else T.BLUE if state == current else T.ACCENT if state in visited else "#72839E"
            for r in ([radius, radius-6] if state in ACCEPTING_STATES else [radius]):
                c.create_oval((x-r)*scale, (y-r)*scale, (x+r)*scale, (y+r)*scale, fill=fill, outline=outline, width=2)
            c.create_text(x*scale, y*scale, text=state, fill=T.TEXT, font=(T.MONO, font_size, "bold"))
        label(750, 795, "Unlisted token categories lead to DEAD. Enable ‘Show rejection edges’ to expand them. Drag to pan.")
